# -*- coding: utf-8 -*-
 
import os
from django.contrib.auth.models import User
from django.contrib import auth
from django.shortcuts import render
from django.shortcuts import render_to_response
from django.views.decorators import csrf 
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import StreamingHttpResponse 
from . import view,db2excel

import sqlite3

BASE_DIR = 'your database location'


# 接收POST请求数据
@csrf_exempt
def search_post(request):
    ctx ={}
    errors= []
    name=None
    sex=None
    age=None
    qq=None
    telephone=None
    wechat=None
    partner=None
    profession=None
    school=None
    xian=None
    habbit=None
    account = request.session.get('account')
    if account == None:
        return HttpResponse("你还没有登录！")
    if request.POST:
        if not request.POST['name']:
            errors.append('请输入姓名！') 
        else:
            name = request.POST['name']	
        if not request.POST['sex']:
            errors.append('请选择性别！')
        else:
            sex = request.POST['sex']
        if not request.POST['age']:
            errors.append('请填写年龄！')
        else:	
            age = request.POST['age']
        if not request.POST['qq']:
            errors.append('请填写QQ号码！')
        else:
            qq = request.POST['qq']
        if not request.POST['telephone']:
            errors.append('请填写手机号码！')
        else:
            telephone = request.POST['telephone']
        if not request.POST['wechat']:
            errors.append('请填写微信号码！')
        else:
            wechat = request.POST['wechat']
        if not request.POST['partner']:
            errors.append('请选择意向部门！')
        else:
            partner = request.POST['partner']
        if not request.POST['profession']:
            errors.append('请填写你的专业和班级！')
        else:
            profession = request.POST['profession']
        sheng = request.POST['sheng']
        shi = request.POST['shi']
        if not request.POST['xian']:
            errors.append('请选择你的家乡地址！')
        else:
            xian = request.POST['xian']
        if not request.POST['school']:
            errors.append('请填写你的毕业高中！')
        else:
            school = request.POST['school']
        if not request.POST['habbit']:
            errors.append('请填写你的兴趣特长！')
        else:
            habbit = request.POST['habbit']
        hometown = sheng + shi + xian
        #return render_to_response('register.html', {'errors': errors})
        #c = conn.cursor()
        #cursor = c.execute("SELECT name from LaoXApp_test")
        #for row in cursor:
        #    if row[0] == name:
        #        return HttpResponse("该姓名已经注册！")
        if name is not None and sex is not None and age is not None and qq is not None and telephone is not None and wechat is not None and partner is not None and profession is not None and xian is not None and school is not None and habbit is not None:
            conn = sqlite3.connect(BASE_DIR + 'laox.db')
            conn.execute("UPDATE LaoXApp_test set name=?,sex=?,age=?,qq=?,telephone=?,wechat=?,partner=?,profession=?,hometown=?,highschool=?,advantage=? where account=?",(name,sex,age,qq,telephone,wechat,partner,profession,hometown,school,habbit,account))
            conn.commit()
            conn.close()
		#ctx['rlt'] = accoun
            return HttpResponse(account)

    return render_to_response('register.html', {'errors': errors})


#account=None #全局变量，便于接受帐号并判断
@csrf_exempt
def alogin(request):  
    errors= []  
    account=None  
    password=None  
    if request.method == 'POST' :  
        if not request.POST.get('account'):  
            errors.append('请输入用户名！')  
        else:  
            account = request.POST.get('account')  
        if not request.POST.get('password'):  
            errors.append('请输入密码！')  
        else:  
            password= request.POST.get('password')  
        if account is not None and password is not None :  
             user = auth.authenticate(username=account,password=password)  
             if user is not None:  
                 if user.is_active:  
                     auth.login(request,user)
                     request.session['account'] = account
                     if len(list(User.objects.get(username=account).get_all_permissions())) > 0:
                         return render_to_response('register_manneger.html')                          
                     else:
                         return render_to_response('register.html')  
                     #return HttpResponse("登录成功！")
                 else:  
                     errors.append('该账户暂时无法使用！')  
             else :  
                  errors.append('用户名或密码错误！')  
    return render_to_response('account/login.html', {'errors': errors})  

@csrf_exempt
def register(request):  
    errors= []  
    account=None  
    password=None  
    password2=None  
    email=None  
    CompareFlag=False  
  
    if request.method == 'POST':  
        if not request.POST.get('account'):  
            errors.append('请输入用户名！')
        elif len(request.POST.get('account')) > 15 or len(request.POST.get('account')) < 4:
            errors.append('用户名长度必须在4到14位之间！')
        else:  
            account = request.POST.get('account')  
        if not request.POST.get('password'):  
            errors.append('请输入密码！')  
        elif len(request.POST.get('password')) < 6:
            errors.append('密码太短！最少得6位！')
        else:  
            password= request.POST.get('password')  
        if not request.POST.get('password2'):  
            errors.append('请再次输入密码！')  
        else:  
            password2= request.POST.get('password2')  
        if not request.POST.get('email'):  
            errors.append('请输入你的邮箱地址！')  
        else:  
            email= request.POST.get('email')  
        if password is not None and password2 is not None:  
            if password == password2:  
                CompareFlag = True  
            else :  
                errors.append('两次输入的密码不一致！')  
  
  
        if account is not None and password is not None and password2 is not None and email is not None and CompareFlag :
            conn = sqlite3.connect(BASE_DIR + 'laox.db')
            c = conn.cursor()
            cursor = c.execute("SELECT username from auth_user")
            for row in cursor:
                if row[0] == account:
                    conn.close()
                    return HttpResponse("该帐号已被注册！")  
            user=User.objects.create_user(account,email,password)  
            user.is_active=True  
            user.save
            conn.execute("INSERT INTO LaoXApp_test (account,name,sex,age,qq,telephone,wechat,partner,profession,hometown,highschool,advantage) VALUES ('%s','%s', '%s', '%s','%s', '%s', '%s','%s', '%s', '%s', '%s', '%s')" % (account,'null','null','null','null','null','null','null','null','null','null','null'))
            conn.commit()
            conn.close()  
            #return HttpResponseRedirect('/account/login')
            return render_to_response('account/register_success.html')
                                         
    return render_to_response('account/register_info.html', {'errors': errors})  
  
def info(request):
    name='null'
    sex='null'
    age='null'
    qq='null'
    telephone='null'
    wechat='null'
    partner='null'
    profession='null'
    hometown='null'
    school='null'
    habbit='null'
    account = request.session.get('account')
    if account == None:
        return HttpResponse("你还没有登录！")
    conn = sqlite3.connect(BASE_DIR + 'laox.db')
    c = conn.cursor()
    cursor = c.execute("SELECT * from LaoXApp_test where account=?" ,(account,))
    for row in cursor:
        name = row[2]
        sex = row[3]
        age = row[4]
        qq = row[5]
        telephone = row[6]
        wechat = row[7]
        partner = row[8]
        profession = row[9]
        hometown = row[10]
        school = row[11]
        habbit = row[12]
    return render_to_response('account/info.html', {'name':name,'sex':sex,'age':age,'qq':qq,'telephone':telephone,'wechat':wechat,'partner':partner,'profession':profession,'hometown':hometown,'school':school,'habbit':habbit})

def big_file_download(request):
    the_xls_path = "/laox.xls"
    the_db_path = "/laox.db"   
    if os.path.exists(the_xls_path):
        os.remove(the_xls_path)
    db2excel.main(the_db_path)  
    def file_iterator(file_name, chunk_size=512):  
        with open(file_name) as f:  
            while True:  
                c = f.read(chunk_size)  
                if c:  
                    yield c  
                else:  
                    break  
  
    response = StreamingHttpResponse(file_iterator(the_xls_path))  
    response['Content-Type'] = 'application/octet-stream'  
    response['Content-Disposition'] = 'attachment;filename="{0}"'.format(the_xls_path)
    return response 

def translate(request):
    if os.path.exists('/laox.xls'):
        os.remove("/laox.xls")
    db2excel.main("/laox.db")
    return HttpResponse(len(list(User.objects.get(username='laoxiang').get_all_permissions())))

def alogout(request):  
    logout(request)  
    return HttpResponseRedirect('/account/login')  #地址重定向






