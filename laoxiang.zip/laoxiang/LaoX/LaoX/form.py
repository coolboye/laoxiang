# -*- coding: utf-8 -*-

from django.shortcuts import render_to_response
 
def register(request):
    return render_to_response('register.html')
 
