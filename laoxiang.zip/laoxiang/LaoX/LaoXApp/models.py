from django.db import models
from django.contrib import admin

# Create your models here.

class Test(models.Model):
    account = models.CharField(max_length=20)
    name = models.CharField(max_length=20, null=True)
    sex = models.CharField(max_length=5, null=True)
    age = models.CharField(max_length=3, null=True)
    qq = models.CharField(max_length=12, null=True)
    telephone = models.CharField(max_length=15, null=True)
    wechat = models.CharField(max_length=20, null=True)
    partner = models.CharField(max_length=15, null=True)
    profession = models.CharField(max_length=30, null=True)
    hometown = models.CharField(max_length=30, null=True)
    highschool = models.CharField(max_length=20, null=True)
    advantage = models.CharField(max_length=50, null=True)

class TestAdmin(admin.ModelAdmin):
    list_display = ('name','sex','age','hometown','highschool')
    search_fields = ('name','hometown','highschool','qq','wechat')

admin.site.register(Test,TestAdmin)
